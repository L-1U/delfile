## Install Python

https://phoenixnap.com/kb/how-to-install-python-3-windows

## Install Package

```
pip install delfile-by-date
```
